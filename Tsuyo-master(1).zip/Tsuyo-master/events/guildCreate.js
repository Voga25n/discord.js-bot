module.exports = (client, guild) => {
  // client.logger.cmd(`[GUILD JOIN]: ${guild.name} (${guild.id}). Owner: ${guild.owner.user.tag} (${guild.owner.user.id})`);
}
